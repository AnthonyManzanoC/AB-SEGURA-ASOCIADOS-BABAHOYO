const fallbackContent = {
  meta: {
    title: "Segura & Manzano | Abogados Asociados en Los Rios",
    description: "Estudio juridico moderno en Montalvo, Babahoyo y Los Rios.",
    keywords: "abogados Montalvo, abogados Babahoyo, estudio juridico Los Rios"
  },
  brand: {
    name: "Segura & Manzano",
    legalName: "Segura & Manzano | Abogados Asociados",
    shortName: "SM",
    tagline: "Experiencia judicial y estrategia legal moderna"
  },
  hero: {
    eyebrow: "Estudio juridico en Montalvo y Los Rios",
    title: "La experiencia que impone respeto.",
    highlight: "La estrategia que mueve el caso.",
    subtitle: "Servicios legales claros, firmes y modernos para personas, familias y negocios de Montalvo, Babahoyo y toda la provincia de Los Rios.",
    primaryCta: "Consultar por WhatsApp",
    secondaryCta: "Ver servicios"
  },
  teamSection: {
    eyebrow: "Nuestro poder",
    title: "Dos perfiles. Una firma con criterio.",
    highlight: "Autoridad + velocidad",
    description: "La trayectoria judicial de una ex jueza se combina con una forma nueva de trabajar."
  },
  servicesSection: {
    eyebrow: "Areas de practica",
    title: "Defensa y asesoria para causas reales.",
    highlight: "Sin vueltas",
    description: "Trabajamos asuntos civiles, familiares, penales, transito, laborales, contractuales e inmobiliarios."
  },
  authoritySection: {
    eyebrow: "Por que elegirnos",
    title: "Un estudio nuevo, con experiencia de sala.",
    highlight: "Y mentalidad actual",
    description: "Seriedad tecnica, comunicacion clara y ejecucion moderna."
  },
  stats: [
    { value: "Ex Jueza", label: "liderazgo juridico civil" },
    { value: "Los Rios", label: "cobertura provincial" },
    { value: "Directo", label: "atencion por WhatsApp" }
  ],
  team: [
    {
      name: "Abg. Zoila Maria Segura Egas",
      role: "Socia principal",
      badge: "Ex Jueza de lo Civil",
      summary: "Autoridad juridica y criterio probado para leer el fondo de cada conflicto.",
      bio: "Su experiencia como Ex Jueza de lo Civil del canton Montalvo aporta una mirada seria, tecnica y practica.",
      imageUrl: "",
      accent: "gold",
      tags: ["Civil", "Familia", "Contratos", "Criterio judicial"]
    },
    {
      name: "Abg. Julio Anthony Manzano Coronel",
      role: "Abogado asociado",
      badge: "Innovacion y estrategia legal",
      summary: "Sangre nueva para impulsar comunicacion rapida, orden digital y seguimiento claro.",
      bio: "Aporta velocidad, tecnologia, organizacion y trato directo para que el cliente sepa donde esta parado.",
      imageUrl: "",
      accent: "blue",
      tags: ["Estrategia", "Tecnologia", "Seguimiento", "Respuesta agil"]
    }
  ],
  services: [
    { title: "Derecho civil", description: "Demandas, obligaciones, contratos, cobros y defensa en procesos civiles.", coverage: "Asesoria civil en Montalvo, Babahoyo y Los Rios.", icon: "scale" },
    { title: "Familia y niñez", description: "Divorcios, alimentos, tenencia, visitas, particiones y acuerdos familiares.", coverage: "Atencion humana y firme para familias.", icon: "family" },
    { title: "Defensa penal", description: "Analisis del caso, acompanamiento, defensa tecnica y actuacion urgente.", coverage: "Respuesta en Babahoyo, Montalvo y cantones cercanos.", icon: "shield" },
    { title: "Transito", description: "Accidentes, infracciones, impugnaciones y defensa en procesos de transito.", coverage: "Cobertura en vias y juzgados de Los Rios.", icon: "route" },
    { title: "Laboral", description: "Despidos, liquidaciones, acuerdos, reclamos y defensa de derechos laborales.", coverage: "Soluciones para trabajadores y empleadores.", icon: "briefcase" },
    { title: "Inmobiliario y tierras", description: "Compraventas, posesion, saneamiento, predios y escrituras.", coverage: "Acompanamiento local en zonas urbanas y rurales.", icon: "building" }
  ],
  authorityPoints: [
    { title: "Lectura judicial del conflicto", description: "Experiencia en judicatura para anticipar riesgos, ordenar pruebas y sostener una posicion legal." },
    { title: "Comunicacion clara", description: "El cliente entiende escenarios, tiempos y el siguiente movimiento." },
    { title: "Presencia local", description: "Conocemos Montalvo, Babahoyo, Mata de Cacao, Simon Bolivar, Pueblo Nuevo y Los Rios." },
    { title: "Ejecucion moderna", description: "Herramientas digitales para ordenar informacion, acelerar respuesta y dar seguimiento." }
  ],
  contact: {
    phone: "+593 XX XXX XXXX",
    whatsApp: "593XXXXXXXXX",
    email: "contacto@seguramanzano.com",
    address: "Montalvo, provincia de Los Rios, Ecuador",
    officeHours: "Lunes a viernes, 08:00 - 18:00. Sabados con cita previa.",
    mapUrl: "https://www.google.com/maps/search/Montalvo,+Los+Rios,+Ecuador",
    coverageCities: ["Montalvo", "Babahoyo", "Mata de Cacao", "Simon Bolivar", "Pueblo Nuevo", "Ventanas", "Quevedo", "Toda la provincia de Los Rios"],
    socialLinks: [
      { label: "Facebook", url: "#" },
      { label: "Instagram", url: "#" },
      { label: "TikTok", url: "#" }
    ]
  },
  visuals: {
    logoUrl: "",
    heroImageUrl: "/assets/segura-office.png"
  }
};

const iconMap = {
  scale: '<svg viewBox="0 0 24 24"><path d="M12 3v18M5 7h14M7 7l-4 7h8L7 7Zm10 0-4 7h8l-4-7Z"/></svg>',
  family: '<svg viewBox="0 0 24 24"><path d="M9 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm6 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM3 21a6 6 0 0 1 12 0M12 21a5 5 0 0 1 9 0"/></svg>',
  shield: '<svg viewBox="0 0 24 24"><path d="M12 3 5 6v5c0 5 3 8 7 10 4-2 7-5 7-10V6l-7-3Z"/></svg>',
  route: '<svg viewBox="0 0 24 24"><path d="M5 19a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm14-8a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM7.5 16H14a5 5 0 0 0 0-10H8"/></svg>',
  briefcase: '<svg viewBox="0 0 24 24"><path d="M9 7V5h6v2M4 8h16v11H4V8Zm0 5h16"/></svg>',
  building: '<svg viewBox="0 0 24 24"><path d="M5 21V4h10v17M15 9h4v12M8 8h4M8 12h4M8 16h4"/></svg>',
  default: '<svg viewBox="0 0 24 24"><path d="M12 3 4 7v6c0 4 3 7 8 9 5-2 8-5 8-9V7l-8-4Z"/></svg>'
};

document.addEventListener("DOMContentLoaded", async () => {
  bindMenu();
  const content = await loadContent();
  renderSite(content);
  bindReveal();
});

async function loadContent() {
  try {
    const response = await fetch("/api/site", { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error("No API content");
    return mergeContent(fallbackContent, await response.json());
  } catch {
    return fallbackContent;
  }
}

function mergeContent(base, incoming) {
  return {
    ...base,
    ...incoming,
    meta: { ...base.meta, ...incoming.meta },
    brand: { ...base.brand, ...incoming.brand },
    hero: { ...base.hero, ...incoming.hero },
    teamSection: { ...base.teamSection, ...incoming.teamSection },
    servicesSection: { ...base.servicesSection, ...incoming.servicesSection },
    authoritySection: { ...base.authoritySection, ...incoming.authoritySection },
    contact: { ...base.contact, ...incoming.contact },
    visuals: { ...base.visuals, ...incoming.visuals }
  };
}

function renderSite(content) {
  const metaDescription = document.querySelector('meta[name="description"]');
  document.title = content.meta.title || content.brand.legalName || fallbackContent.meta.title;
  if (metaDescription) metaDescription.content = content.meta.description || fallbackContent.meta.description;

  setText("brandName", content.brand.name);
  setText("brandTagline", content.brand.tagline);
  setText("footerBrand", content.brand.legalName || content.brand.name);
  setText("footerText", content.brand.tagline);

  const brandMark = document.getElementById("brandMark");
  if (content.visuals.logoUrl) {
    brandMark.innerHTML = `<img src="${safeAttr(content.visuals.logoUrl)}" alt="${safeAttr(content.brand.name)}">`;
  } else {
    brandMark.textContent = content.brand.shortName || initials(content.brand.name);
  }

  const heroImage = document.getElementById("heroImage");
  if (content.visuals.heroImageUrl) heroImage.src = content.visuals.heroImageUrl;

  setText("heroEyebrow", content.hero.eyebrow);
  setText("heroTitle", content.hero.title);
  setText("heroHighlight", content.hero.highlight);
  setText("heroSubtitle", content.hero.subtitle);
  setText("heroPrimary", content.hero.primaryCta, "span");
  setText("heroSecondary", content.hero.secondaryCta, "span");

  const whatsAppUrl = buildWhatsAppUrl(content.contact.whatsApp, `Hola, soy visitante de ${content.brand.name}. Quiero consultar un caso legal.`);
  ["navWhatsapp", "heroPrimary", "contactWhatsapp", "floatWhatsapp"].forEach(id => setHref(id, whatsAppUrl));
  setHref("contactEmail", `mailto:${content.contact.email || ""}`);

  setText("teamEyebrow", content.teamSection.eyebrow);
  setText("teamTitle", content.teamSection.title);
  setText("teamHighlight", content.teamSection.highlight);
  setText("teamDescription", content.teamSection.description);

  setText("servicesEyebrow", content.servicesSection.eyebrow);
  setText("servicesTitle", content.servicesSection.title);
  setText("servicesHighlight", content.servicesSection.highlight);
  setText("servicesDescription", content.servicesSection.description);

  setText("authorityEyebrow", content.authoritySection.eyebrow);
  setText("authorityTitle", content.authoritySection.title);
  setText("authorityHighlight", content.authoritySection.highlight);
  setText("authorityDescription", content.authoritySection.description);

  renderStats(content.stats || []);
  renderTeam(content.team || []);
  renderServices(content.services || []);
  renderAuthority(content.authorityPoints || []);
  renderContact(content.contact || fallbackContent.contact);
}

function renderStats(stats) {
  const target = document.getElementById("statsList");
  target.innerHTML = stats.map(item => `
    <div class="stat reveal">
      <strong>${escapeHtml(item.value)}</strong>
      <span>${escapeHtml(item.label)}</span>
    </div>
  `).join("");
}

function renderTeam(team) {
  const target = document.getElementById("teamGrid");
  target.innerHTML = team.map(member => {
    const image = member.imageUrl
      ? `<img src="${safeAttr(member.imageUrl)}" alt="Foto de ${safeAttr(member.name)}">`
      : `<div class="team-initials">${escapeHtml(initials(member.name))}</div>`;
    const tags = (member.tags || []).map(tag => `<span class="pill">${escapeHtml(tag)}</span>`).join("");
    return `
      <article class="team-card ${escapeHtml(member.accent || "gold")} reveal">
        <div class="team-photo">${image}</div>
        <div class="team-body">
          <span class="badge">${escapeHtml(member.badge)}</span>
          <h3>${escapeHtml(member.name)}</h3>
          <h4>${escapeHtml(member.role)}</h4>
          <p>${escapeHtml(member.summary || member.bio)}</p>
          <div class="team-tags">${tags}</div>
        </div>
      </article>
    `;
  }).join("");
}

function renderServices(services) {
  const target = document.getElementById("servicesGrid");
  target.innerHTML = services.map(service => `
    <article class="service-card reveal">
      <div class="service-icon">${iconMap[service.icon] || iconMap.default}</div>
      <h3>${escapeHtml(service.title)}</h3>
      <p>${escapeHtml(service.description)}</p>
      <small>${escapeHtml(service.coverage)}</small>
    </article>
  `).join("");
}

function renderAuthority(points) {
  const target = document.getElementById("authorityPoints");
  target.innerHTML = points.map((point, index) => `
    <article class="authority-card reveal">
      <span>${index + 1}</span>
      <h3>${escapeHtml(point.title)}</h3>
      <p>${escapeHtml(point.description)}</p>
    </article>
  `).join("");
}

function renderContact(contact) {
  const target = document.getElementById("contactPanel");
  const coverage = (contact.coverageCities || []).map(city => `<span class="pill">${escapeHtml(city)}</span>`).join("");
  const socials = (contact.socialLinks || [])
    .filter(link => link.label)
    .map(link => `<a class="pill" href="${safeAttr(link.url || "#")}" target="_blank" rel="noopener">${escapeHtml(link.label)}</a>`)
    .join("");

  target.innerHTML = `
    <div class="contact-row"><strong>Telefono</strong><span>${escapeHtml(contact.phone)}</span></div>
    <div class="contact-row"><strong>WhatsApp</strong><a href="${safeAttr(buildWhatsAppUrl(contact.whatsApp, "Hola, quisiera una consulta legal."))}" target="_blank" rel="noopener">${escapeHtml(contact.whatsApp)}</a></div>
    <div class="contact-row"><strong>Correo</strong><a href="mailto:${safeAttr(contact.email)}">${escapeHtml(contact.email)}</a></div>
    <div class="contact-row"><strong>Direccion</strong><span>${escapeHtml(contact.address)}</span></div>
    <div class="contact-row"><strong>Horario</strong><span>${escapeHtml(contact.officeHours)}</span></div>
    <div class="contact-row"><strong>Mapa</strong><a href="${safeAttr(contact.mapUrl || "#")}" target="_blank" rel="noopener">Abrir ubicacion</a></div>
    <div class="contact-row"><strong>Cobertura</strong><div class="coverage-tags">${coverage}</div></div>
    <div class="contact-row"><strong>Redes</strong><div class="social-links">${socials}</div></div>
  `;
}

function bindMenu() {
  const toggle = document.getElementById("navToggle");
  const links = document.getElementById("navLinks");
  toggle.addEventListener("click", () => {
    const open = links.classList.toggle("open");
    toggle.setAttribute("aria-expanded", String(open));
    document.body.classList.toggle("menu-open", open);
  });

  links.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      links.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
      document.body.classList.remove("menu-open");
    });
  });
}

function bindReveal() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("in-view");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.14 });

  document.querySelectorAll(".reveal").forEach(element => observer.observe(element));
}

function buildWhatsAppUrl(phone, message) {
  const digits = String(phone || "").replace(/\D/g, "") || "593";
  return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
}

function initials(value) {
  return String(value || "SM")
    .split(/\s|&/)
    .filter(Boolean)
    .slice(0, 2)
    .map(part => part[0])
    .join("")
    .toUpperCase();
}

function setText(id, value, selector) {
  const element = document.getElementById(id);
  if (!element) return;
  const target = selector ? element.querySelector(selector) : element;
  if (target) target.textContent = value || "";
}

function setHref(id, value) {
  const element = document.getElementById(id);
  if (element) element.href = value || "#";
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function safeAttr(value) {
  return escapeHtml(value).replaceAll("`", "&#096;");
}
