﻿using Microsoft.EntityFrameworkCore;
using SeguraLegal.API.Services;
using SeguraLegal.Application.Interfaces;
using SeguraLegal.Infrastructure.Persistence;
using SeguraLegal.Infrastructure.Repositories;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins("http://localhost:4200", "http://localhost:5173", "http://localhost:5000", "http://localhost:5285")
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var supabaseConnection = builder.Configuration.GetConnectionString("Supabase");
var hasSupabaseConnection =
    !string.IsNullOrWhiteSpace(supabaseConnection) &&
    !supabaseConnection.Contains("__", StringComparison.OrdinalIgnoreCase) &&
    !supabaseConnection.Contains("CAMBIAR", StringComparison.OrdinalIgnoreCase);

if (hasSupabaseConnection)
{
    builder.Services.AddDbContext<SeguraDbContext>(options => options.UseNpgsql(supabaseConnection));
    builder.Services.AddScoped<ISiteContentStore, EfSiteContentStore>();
    builder.Services.AddScoped<IConsultaRepository, ConsultaRepository>();
}
else
{
    builder.Services.AddSingleton<ISiteContentStore, JsonFileSiteContentStore>();
}

builder.Services.AddSingleton<AdminTokenService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

if (!app.Environment.IsDevelopment())
{
    app.UseHttpsRedirection();
}

app.UseDefaultFiles();
app.UseStaticFiles();
app.UseCors("AllowFrontend");
app.UseAuthorization();
app.MapControllers();
app.MapFallbackToFile("index.html");

app.Run();
